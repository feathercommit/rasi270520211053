<!-- Page header start -->
<div class="page-header">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Branch Creation</li>
					</ol>

					
				</div>
				<!-- Page header end -->
				
				<!-- Main container start -->
				<div class="main-container">
                <form id="branch" name="branch" action="" method="post">			
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">General Info</div>
								<div class="card-body">
									<!-- Row start -->
									<div class="row gutters">
										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Branch Name</label><span class="text-danger">*</span>
													<input type="text" tabindex="1"  name="branchname" id="branchname" class="form-control" placeholder="Enter Branch Name">
													<span class="text-danger" id="branchnamecheck">Enter Branch Name</span>
											</div>
										</div>
										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Address</label><span class="text-danger">*</span>
													<input type="text" tabindex="2"  name="address" id="address" class="form-control" placeholder="Enter Address">
													<span class="text-danger" id="addresscheck">Enter Address</span>
											</div>
										</div>
										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Address1</label>
													<input type="text" tabindex="3"   name="Address1" id="Address1" class="form-control" placeholder="Enter Address1">
												</div>
											</div>


											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Address2</label>
													<input type="number" tabindex="4"   name="Address2" id="Address2" class="form-control" placeholder="Enter Address2">
												</div>
										</div>
										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Pin Code</label><span class="text-danger">*</span>
													<input type="number" tabindex="5" name="pincode" id="pincode" value="" class="form-control" placeholder="Enter Pincode">
													<span class="text-danger" id="pincodecheck">Enter Pincode</span>
											</div>
										</div>
										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">State</label><span class="text-danger">*</span>
													<input type="text" tabindex="6" name="state" id="state" class="form-control" placeholder="Enter State">
													<span class="text-danger" id="statecheck">Enter State</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Country</label><span class="text-danger">*</span>
													<input type="text" tabindex="7" name="country" id="country" class="form-control" placeholder="Enter Country">
													<span class="text-danger" id="countrycheck">Enter Country</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Phone Number</label><span class="text-danger">*</span>
													<input type="number" tabindex="8" name="phonenumber" id="phonenumber" class="form-control" placeholder="Enter Phone Number">
													<span class="text-danger" id="phonenumbercheck">Enter Phone Number</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Mail Id</label><span class="text-danger">*</span>
													<input type="text" tabindex="9" name="email" id="email" class="form-control" placeholder="Enter Mail Id">
													<span class="text-danger" id="emailcheck">Enter Mail Id</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Fax Number</label><span class="text-danger">*</span>
													<input type="text" tabindex="10" name="faxnumber" id="faxnumber" class="form-control" placeholder="Enter Fax Number">
													<span class="text-danger" id="faxnumbercheck">Enter Fax Number</span>
												</div>
											</div>



										

									</div>
									<!-- Row end -->

								</div>
							</div>

							<div class="card">
								<div class="card-header">Tax Info </div>
								<div class="row card-body">
								<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">TAN No</label><span class="text-danger">*</span>
													<input type="text" tabindex="11" name="tanno" id="tanno" class="form-control" placeholder="Enter TAN No">
													<span class="text-danger" id="tannocheck">Enter TAN No</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">GST</label><span class="text-danger">*</span>
													<input type="text"  tabindex="12"  name="gst" id="gst" class="form-control" placeholder="Enter GST">
													<span class="text-danger" id="gstcheck">Enter GST</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">PF No</label><span class="text-danger">*</span>
													<input type="text"  tabindex="13"  name="pfno" id="pfno" class="form-control" placeholder="Enter PF No">
													<span class="text-danger" id="pfnocheck">Enter PF No</span>
												</div>
											</div>
											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">ESIC No</label><span class="text-danger">*</span>
													<input type="text"  tabindex="14"  name="esicno" id="esicno" class="form-control" placeholder="Enter ESIC No">
													<span class="text-danger" id="esicnocheck">Enter ESIC No</span>
												</div>
											</div>
								</div>

								<div class="row">
									<div class="col-md-4">
									</div>

									<div class="col-md-4">
									</div>

									
								</div>

							</div>

							<div class="card">
								<div class="card-header">Other Info</div>
								<div class="row card-body">
									
								<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Login - Shorter Name</label><span class="text-danger">*</span>
													<input type="text"  tabindex="15"  name="loginshortername" id="loginshortername" class="form-control" placeholder="Enter Login - Shorter Name">
													<span class="text-danger" id="loginshorternamecheck">Enter Login - Shorter Name</span>
												</div>
											</div>
								</div>

								<div class="row">
									<div class="col-md-4">
									</div>

									<div class="col-md-4">
									</div>

									<div class="col-md-4">
										<button type="button"  tabindex="16"  id="submitbranchbtn" name="submitbranchbtn" class="btn btn-primary">Submit</button>
										<button type="reset"  tabindex="17"  id="cancelbtn" name="cancelbtn" class="btn btn-outline-secondary">Cancel</button><br /><br />
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- Row end -->
					</form>

				</div>